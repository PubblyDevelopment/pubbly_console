class DomInteractionCover {
    promptClick(cb) {
        let height = this.container.height();
        let width = this.container.width();
        this.container.append(`
         <div class='domInteractionCoverCont' 
         style='position:absolute;height:${height}px;width:${width}px;background-color:white'> 
         <img src="${this.picked.relPath}"
         class='transformCenter cursor-pointer'
         style='max-height: 100%' 
         loop=infinite />
         </div>`);
        this.cb = cb;
        this.container[0].addEventListener("click", this.clicked);
    }

    clicked() {
        this.container.find(".domInteractionCoverCont").remove();
        this.container[0].removeEventListener("click", this.clicked);
        this.cb();
        this.cb = false;
    }

    constructor(container) {
        this.container = container;
        this.clicked = this.clicked.bind(this);
        
        this.cb = false;
        this.available = [
            "dom_click_bee1.gif",
            "dom_click_bee2.gif",
            "dom_click_mathazzar.gif",
            "dom_click_bird.gif",
            "dom_click_pup.gif",
            "dom_click_wordtopia.gif",
        ].map(e => {
            return {
                type: "gif",
                relPath: "assets/" + e
            }
        });
        this.picked = randInArray(this.available);
    }
}
