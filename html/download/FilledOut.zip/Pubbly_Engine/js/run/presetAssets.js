class PubblyPresetAssets {
	add(asset) {
		let already = this.list.find(a => a.src === asset.src);
		if (!already) {
			this.list.push(asset);
		}
	}

	constructor(rootToEngine) {
		this.list = [];
		this.loader = new AssetListLoader();
		this.load = this.loader.load.bind(this.loader, this.list);

		this.add({type: "image", relPath: rootToEngine + "assets/texture_blackboard.png"});
		this.add({type: "image", relPath: rootToEngine + "assets/cursor_pencil.png"});
		this.add({type: "image", relPath: rootToEngine + "assets/cursor_chalk.png"});
		this.add({type: "image", relPath: rootToEngine + "assets/cursor_eraser.png"});
		this.add({type: "image", relPath: rootToEngine + "assets/cursor_pencil.png"});
		this.add({type: "image", relPath: rootToEngine + "assets/logo_fill_letters.png"});
		this.add({type: "audio", relPath: rootToEngine + "assets/audio_blank.mp3"});
	}
}
