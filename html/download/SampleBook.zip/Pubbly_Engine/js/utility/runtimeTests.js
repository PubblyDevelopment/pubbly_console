class RuntimeTests {
    canAutoplay(cbs) {
        /*
         * cbs to fail or done boolean
         * Attempts to autoplay an empty audio file, to see if the chome update of "NO autoplay before dom interaction" blocks it.
         */
        let testAud = new Audio();
        testAud.onerror = function() {
            console.log('bad');
        };
        testAud.play().catch(function(err) {
            if (err.code !== 0) {
                console.warn("Attempted to test for canAutoplay, and errored, but codr unknown... Still returning false");
            }
            cbs.fail();
        });
        testAud.addEventListener("play", cbs.done);
    }
    constructor() {
    }
}
